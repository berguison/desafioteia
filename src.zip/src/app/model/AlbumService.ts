import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Foto } from "../model/Fotos";

@Injectable({
  providedIn: 'root'
})
export class AlbumService {
  private apiUrl = 'https://jsonplaceholder.typicode.com/photos/';

  constructor(private http: HttpClient) { }

  getItemAlbum(userId: number): Observable<Foto> {
    const url = 'https://jsonplaceholder.typicode.com/photos/'+userId;//'${this.apiUrl}?userId=${userId}' ;
    return this.http.get<Foto>(url);
  }
} 
