export interface Foto {
    albumId: number,
    id: number,
    title: string,
    thumbnailUrl:string,
    url:string
  }
  