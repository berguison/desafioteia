import { AfterViewInit, Component, OnInit,ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { HttpClient } from '@angular/common/http';
import { MatTableDataSource } from '@angular/material/table'; 
import { Router } from '@angular/router';

export interface Photo {
  albumId:number;
  id: number;
  thumbnailUrl: string;
  title: string;
  url: string;
  
}
@Component({
  selector: 'app-lista-imagens',
  templateUrl: './lista-imagens.component.html',
  styleUrls: ['./lista-imagens.component.css']
})

export class ListaImagensComponent implements AfterViewInit {
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  constructor(private http: HttpClient,
     private router: Router) { }
 
  dataSource = new MatTableDataSource<Photo>();
  displayedColumns: string[] = ['albumId', 'id','thumbnailUrl', 'title', 'url' ,'Acoes'];
  ngAfterViewInit(): void {
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
    this.getFotos(); 
  }
 
  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  rowClicked(row: any): void {
    console.log(row);
  }
  getFotos() {
    this.http.get<Photo[]>('https://jsonplaceholder.typicode.com/photos')
      .subscribe(data => {
      this.dataSource.data = data;
      console.log(data);
      });
  }
 
  viewDetails(id: any) {
    console.log("Número do idALMBum",id);
    this.router.navigate(['/detalhar-imagem',id]);
   // console.log("Detalhes da foto:", row);:{row}
  }

  addToCart(row: Photo) {
    // Lógica para adicionar ao carrinho
    console.log("Adicionado ao carrinho:", row);
  }

}


