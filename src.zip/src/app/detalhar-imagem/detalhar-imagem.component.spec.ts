import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetalharImagemComponent } from './detalhar-imagem.component';

describe('DetalharImagemComponent', () => {
  let component: DetalharImagemComponent;
  let fixture: ComponentFixture<DetalharImagemComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetalharImagemComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DetalharImagemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
