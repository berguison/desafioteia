import { Component, Input, OnInit } from '@angular/core';
import { Foto } from '../model/Fotos';
import { HttpClient } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { AlbumService } from '../model/AlbumService';




import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detalhar-imagem',
 
  templateUrl: './detalhar-imagem.component.html',
  styleUrl: './detalhar-imagem.component.css'
})
export class DetalharImagemComponent implements OnInit {

  texto: string;
  @Input() Album: Foto = {
    albumId: 0,
    id: 0,
    title: "",
    thumbnailUrl:"",
    url:""
  };
  comentario: any[];
  baseUrl = 'https://jsonplaceholder.typicode.com/photos';
  constructor(
    private http: HttpClient,
     private router: ActivatedRoute,private service: AlbumService){ this.texto = '', this.comentario=[]}

  
  ngOnInit(): void {
    this.router.paramMap.subscribe(params => {
      const idAlbum = params.get('id')
      this.getAlbum(idAlbum);
      
    });
   

      
      console.log("Detalhes da foto:",this.Album);
    
  }
  getAlbum(id:any){
   
      this.service.getItemAlbum(id)
        .subscribe(data => {
        this.Album = data;
    })
}

PostarComentario(){
  this.comentario[0]=this.texto;
  console.log(this.comentario );
}

} 
