import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import{ListaImagensComponent} from './lista-imagens/lista-imagens.component'
import{DetalharImagemComponent} from './detalhar-imagem/detalhar-imagem.component'
import{CarrinhoComponent} from './carrinho/carrinho.component'

const routes: Routes = [
  {path: 'lista-imagens', component: ListaImagensComponent},
  {path: 'detalhar-imagem/:id', component: DetalharImagemComponent},
  {path: 'carrinho', component: CarrinhoComponent},
  { path: '', redirectTo: '/lista-imagens', pathMatch: 'full' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
